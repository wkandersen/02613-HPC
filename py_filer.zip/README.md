# 02613-HPC
Miniproject in the course Python and High Performance Computing at DTU

source /dtu/projects/02613_2025/conda/conda_init.sh

conda activate 02613